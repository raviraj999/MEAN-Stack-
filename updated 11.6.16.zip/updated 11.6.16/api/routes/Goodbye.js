﻿module.exports = function () {

    console.log("GoodBye");
};
